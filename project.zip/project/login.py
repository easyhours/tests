import requests, json, lxml.html, pprint, os, sys
from helpers import Helpers

login_data = {
    'app_version': '303551284', 
    'source_token': '', 
    'app_name': 'com.amazon.rabbit', 
    'requested_token_type': 'access_token', 
    'source_token_type': 'refresh_token'
}

auth_headers = {
    'Host': 'api.amazon.in', 
    'Content-Type': 'application/json', 
    'User-Agent': 'Dalvik/1.6.0 (Linux; U; Android 4.4.2; SM-G955N Build/NRD90M)', 
    'x-amzn-identity-auth-domain': 'api.amazon.in'
}

with open('registration_data.json', 'r') as (read_json):
    registration_data = json.load(read_json)
    login_data['device_metadata'] = registration_data['device_metadata']

_session = requests.Session()

class AccessToken(Helpers):

    def __init__(self):
        Helpers.__init__(self)
        # self.proxies = {
        #     'http': 'http://54.172.90.48:8007/',
        #     'https': 'http://54.172.90.48:8007/'
        # }

        self.proxies = None
        self.prep_helpers()

    def register(self):
        print('Registering Token')
        registration_response = _session.post('https://api.amazon.in/auth/register', headers=auth_headers, data=json.dumps(registration_data), proxies=self.proxies)
        print("***=>" , registration_response.status_code)
        if registration_response.status_code == 200:
            registration_response_data = registration_response.json()
            source_token = registration_response_data['response']['success']['tokens']['bearer']['refresh_token']
            access_token = registration_response_data['response']['success']['tokens']['bearer']['access_token']
            self.update_settings(access_token, source_token)
            return access_token
        if registration_response.status_code == 401:
            open("not_logging.txt", "w+")
            print(registration_response.text)
            print('Challenge Detected')
            registration_response_json = registration_response.json()
            h = {'Host': 'www.amazon.in', 
             'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8', 
             'User-Agent': 'Mozilla/5.0 (Linux; Android 4.4.2; SM-G930K Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36', 
             'Accept-Encoding': 'gzip,deflate', 
             'Accept-Language': 'en-IN,en-US;q=0.8', 
             'X-Requested-With': 'com.amazon.rabbit', 
             'Cookie': 'frc=AKShf6NdG4ah4lwTGEIG3BQtFGCySQ6/BfUJIJsiHqwPMojvfP/1YkQ/1Ime1QKK03vNsxUeIKyaoSTZr+QMhjRD4OB3Jyog/Vh2cz8Lv2BA5hNki8gHt9ilh0PSaMuUQIb6ggchJ9a6Lau+US0vRQyKAOSGAAMwjhcrt1vFvsLj3nZiiSVF5WrF3Ol3V+EGRbewzpuEGfs4u/h2MqrkjfDTv0kd4AZWDAJr7d/nheIc7dZt+Ut4w9DkPFsGvZn60sg9Xdbs++9qcW1bUM8ysZ9S63yDwrtb2Z2VtA30qElroL8r5lQFlFqGgBT23cr5vyt71+g26B1QNJg/E8qS4Lzj2yS40wFm6KpPU/n0ZRfDBqbjqXIc8bt6MXNKlQrJZ5KLQuwftKVDNSlacY8FpgWiFSG5R4ZcZX75XMo4Fd9qDsn6QtDtLivhafubDU8Zutewv6tY39tr; map-md=eyJhcHBfaW5mbyI6eyJwZXJtaXNzaW9uX3J1bnRpbWVfZ3JhbnQiOjAsImF1dG9fcHYiOjB9LCJkZXZpY2VfZGF0YSI6eyJtb2JpbGVfc2ltX2NvdW50cnlfaXNvIjoiSU4ifSwiYXBwX2lkZW50aWZpZXIiOnsiU0hBLTI1NiI6WyIyZjE5YWRlYjI4NGViMzZmN2YwNzc4NjE1MmI5YTFkMTRiMjE2NTMyMDNhZDBiMDRlYmJmOWM3M2FiNmQ3NjI1Il0sInBhY2thZ2UiOiJjb20uYW1hem9uLnJhYmJpdCIsImFwcF92ZXJzaW9uIjoiMzAzNTUxMjg0IiwibWFwX3ZlcnNpb24iOiJNQVBBbmRyb2lkTGliLTEuMS4yMDA3MDEuMCJ9LCJkZXZpY2VfcmVnaXN0cmF0aW9uX2RhdGEiOnsic29mdHdhcmVfdmVyc2lvbiI6IjEzMDA1MDAwMiJ9fQ==; sid='}
            cook = {'frc': 'AKShf6NdG4ah4lwTGEIG3BQtFGCySQ6/BfUJIJsiHqwPMojvfP/1YkQ/1Ime1QKK03vNsxUeIKyaoSTZr+QMhjRD4OB3Jyog/Vh2cz8Lv2BA5hNki8gHt9ilh0PSaMuUQIb6ggchJ9a6Lau+US0vRQyKAOSGAAMwjhcrt1vFvsLj3nZiiSVF5WrF3Ol3V+EGRbewzpuEGfs4u/h2MqrkjfDTv0kd4AZWDAJr7d/nheIc7dZt+Ut4w9DkPFsGvZn60sg9Xdbs++9qcW1bUM8ysZ9S63yDwrtb2Z2VtA30qElroL8r5lQFlFqGgBT23cr5vyt71+g26B1QNJg/E8qS4Lzj2yS40wFm6KpPU/n0ZRfDBqbjqXIc8bt6MXNKlQrJZ5KLQuwftKVDNSlacY8FpgWiFSG5R4ZcZX75XMo4Fd9qDsn6QtDtLivhafubDU8Zutewv6tY39tr', 
             'map-md': 'eyJhcHBfaW5mbyI6eyJwZXJtaXNzaW9uX3J1bnRpbWVfZ3JhbnQiOjAsImF1dG9fcHYiOjB9LCJkZXZpY2VfZGF0YSI6eyJtb2JpbGVfc2ltX2NvdW50cnlfaXNvIjoiSU4ifSwiYXBwX2lkZW50aWZpZXIiOnsiU0hBLTI1NiI6WyIyZjE5YWRlYjI4NGViMzZmN2YwNzc4NjE1MmI5YTFkMTRiMjE2NTMyMDNhZDBiMDRlYmJmOWM3M2FiNmQ3NjI1Il0sInBhY2thZ2UiOiJjb20uYW1hem9uLnJhYmJpdCIsImFwcF92ZXJzaW9uIjoiMzAzNTUxMjg0IiwibWFwX3ZlcnNpb24iOiJNQVBBbmRyb2lkTGliLTEuMS4yMDA3MDEuMCJ9LCJkZXZpY2VfcmVnaXN0cmF0aW9uX2RhdGEiOnsic29mdHdhcmVfdmVyc2lvbiI6IjEzMDA1MDAwMiJ9fQ==', 
             'sid': ''}
            challenge_url = registration_response_json['response']['challenge']['uri'] + '&openid.oa2.client_id=device%3A33656435363264303837646634613737616163346662373163333632323237322341314d50534c4643374c3541464b&openid.oa2.response_type=token&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&pageId=amzn_device_common_dark&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=amzn_device_in&disableLoginPrepopulate=0&accountStatusPolicy=P1&openid.pape.max_auth_age=0&openid.ns.oa2=http%3A%2F%2Fwww.amazon.com%2Fap%2Fext%2Foauth%2F2&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&language=en_IN&openid.oa2.scope=device_auth_access&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fap%2Fmaplanding'
            print('\n\n#########################')
            print(challenge_url)
            print('\n\n#########################')
            get_challenge = _session.get(challenge_url, headers=h)
            print('\n\n')
            pprint.pprint(dict(get_challenge.request.headers))
            print(get_challenge)
            print(get_challenge.url)
            print('\n\n')
            challenge_xml = lxml.html.fromstring(get_challenge.content)
            hidden_inputs = challenge_xml.xpath('//input[@type="hidden"]')
            print(hidden_inputs)
            print(hidden_inputs[0].attrib)
            q = {str(elm.attrib.get('name')):str(elm.attrib.get('value')) for elm in hidden_inputs}
            pprint.pprint(q)
        else:
            print(registration_response.text)
        print('Error occured while registering, check your username and password')

    def refresh(self):
        auth_headers_refresh = auth_headers.copy()
        auth_headers_refresh['User-Agent'] = 'AmazonWebView/MAPClientLib/130050002/Android/4.4.2/SM-G955N'
        refresh_response = _session.post('https://api.amazon.in/auth/token', headers=auth_headers_refresh, data=json.dumps(login_data), proxies=self.proxies)

        if refresh_response.status_code == 200:
            refresh_response_data = refresh_response.json()
            access_token = refresh_response_data['access_token']
            self.update_settings(access_token, self.SOURCE_TOKEN)
            print("=================")
            print(refresh_response_data)
            print("*****************")
            return access_token
        if refresh_response.status_code == 401:
            print('Code Verification required')
        else:
            if refresh_response.status_code == 400:
                print('Removing source token from file and refreshing')
                print(refresh_response.text)
                access_token = self.settings.get('ACCESS_TOKEN')
                self.update_settings(access_token, '')
                self.update_token(self.EMAIL, self.PASSWORD, '')
        print('Error occured while registering, check your username and password')

    def update_token(self, EMAIL, PASSWORD, SOURCE_TOKEN):
        self.SOURCE_TOKEN = SOURCE_TOKEN
        self.EMAIL = EMAIL
        self.PASSWORD = PASSWORD

        login_data['source_token'] = SOURCE_TOKEN
        registration_data['auth_data']['user_id_password']['user_id'] = EMAIL
        registration_data['auth_data']['user_id_password']['password'] = PASSWORD

        if self.SOURCE_TOKEN:
            access_token = self.refresh()
            if access_token:
                return access_token
        else:
            access_token = self.register()
        if access_token:
            return access_token
        