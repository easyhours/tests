import datetime, json, os, requests

class Helpers(object):

    def __init__(self):
        self.BASE_DIR = 'DATA'
        self.SETTINGS_FILE_NAME = 'DATA/settings.json'
        self.HEADERS_FILE_NAME = '../headers.json'

    def check_create_dir_files(self):
        if not os.path.isdir(self.BASE_DIR):
            os.mkdir(self.BASE_DIR)
        if not os.path.isfile(self.SETTINGS_FILE_NAME):
            with open(self.SETTINGS_FILE_NAME, 'w') as (create_file):
                create_file.write(json.dumps({'EMAIL': 'alba@re-gister.com', 
                    'PASSWORD': 'alba123', 
                    'ACCESS_TOKEN': '', 
                    'SOURCE_TOKEN': '', 
                    'SERVICE_AREA_ID': '23', 
                    'THREADS': '1', 
                    'SLEEP_TIME': '0.12', 
                    'RUNNING_TIME': '1740',
                    'REQ_SLEEP_TIME': '180',
                    'AUTO_STOP': 'ON',
                    'ERROR_QUANTITY': '4',
                    'FILTER_SIDS': ['29571892-da88-4089-83f0-24135852c2e4', '5548b40b-1223-4881-87b1-4ae5d4d77f95'], 
                    'MIN_AMOUNT': '34', 
                    'NEXT_DAY': 'NO',
                    'NOTIFICATION_EMAILS': []}, indent=4))
        if not os.path.isfile(self.HEADERS_FILE_NAME):
            with open(self.HEADERS_FILE_NAME, 'w') as (create_file):
                create_file.write(json.dumps({'Host': 'flex-capacity-na.amazon.com', 
                    'User-Agent': 'Dalvik/1.6.0 (Linux; U; Android 4.4.2; SM-G930K Build/NRD90M) RabbitAndroid/3.7.145.0', 
                    'Content-Type': 'application/json', 
                    'Accept-Encoding': 'gzip'}, indent=4))

    def get_settings(self):
        with open(self.SETTINGS_FILE_NAME, 'r') as (read_settings):
            settings = json.load(read_settings)
        return settings

    def update_settings(self, ACCESS_TOKEN, SOURCE_TOKEN):
        settings = self.get_settings()
        settings.update({'ACCESS_TOKEN': ACCESS_TOKEN, 
         'SOURCE_TOKEN': SOURCE_TOKEN})
        with open(self.SETTINGS_FILE_NAME, 'w') as (save_settings):
            save_settings.write(json.dumps(settings, indent=4))
        return settings

    def get_headers(self):
        with open(self.HEADERS_FILE_NAME, 'r') as (read_headers):
            headers = json.load(read_headers)
        return headers

    def init_session(self):
        new_session = requests.Session()
        new_session.headers.update(self.get_headers())
        return new_session

    def init_urls(self):
        service_area_id = self.settings.get('SERVICE_AREA_ID')
        self.refresh_block_url = ('https://flex-capacity-na.amazon.com/GetOffersForProvider?serviceAreaIds={0}&apiVersion=V2').format(service_area_id)

    def prep_helpers(self):
        self.check_create_dir_files()
        self.settings = self.get_settings()
        try:
            self.settings['SLEEP_TIME'] = float(self.settings['SLEEP_TIME'])
            self.settings['REQ_SLEEP_TIME'] = float(self.settings['REQ_SLEEP_TIME'])
            self.settings['ERROR_QUANTITY'] = int(self.settings['ERROR_QUANTITY'])
            self.settings['RUNNING_TIME'] = float(self.settings['RUNNING_TIME'])
        except:
            print('Error Happens here')
        else:
            self.base_headers = self.get_headers()
            self.session = self.init_session()
            self.init_urls()