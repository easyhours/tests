
import datetime, pytz, uuid

class HMACHeaders(object):

    def __init__(self):
        self.tz = pytz.timezone('America/New_York')
        self.headers = {}

    def get_formatted_tstamp(self):
        ct = datetime.datetime.now(tz=self.tz)
        return str(int(ct.timestamp()*1000))

    def prepare_canonical_get_request(self):
        flex_client_time = self.get_formatted_tstamp()
        self.headers['X-Flex-Client-Time'] = flex_client_time

    def prepare_canonical_post_request(self):
        flex_client_time = self.get_formatted_tstamp()
        self.headers['X-Flex-Client-Time'] = flex_client_time

    def new_post_getoffer(self, amz_access_token):
        self.amz_access_token = amz_access_token
        self.headers['x-amz-access-token'] = self.amz_access_token
        self.headers['x-flex-instance-id'] = self.flex_instance_id
        return {'Accept-Language': 'en_US'}

    def post_hmac_header(self, amz_access_token):
        self.amz_access_token = amz_access_token
        self.headers['x-amz-access-token'] = self.amz_access_token
        self.headers['x-flex-instance-id'] = self.flex_instance_id
        self.prepare_canonical_post_request()
        return {'X-Amzn-RequestId': str(uuid.uuid4())}